import { useState } from 'react'

export default function Login({ onLogin }) {
  const [user, setUser] = useState('loan.officer')
  const [pass, setPass] = useState('demo1234')

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white border border-gray-100 rounded-xl p-8 w-80 shadow-sm">
        <div className="flex items-center gap-3 mb-6">
          <span className="text-3xl">🏦</span>
          <div>
            <p className="font-medium text-gray-900">CreditGuard Bank</p>
            <p className="text-xs text-gray-400">Loan Risk Intelligence</p>
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Username</label>
            <input
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand"
              value={user}
              onChange={e => setUser(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-500 uppercase tracking-wide mb-1">Password</label>
            <input
              type="password"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand"
              value={pass}
              onChange={e => setPass(e.target.value)}
            />
          </div>
          <button
            onClick={onLogin}
            className="w-full bg-brand hover:bg-brand-dark text-white text-sm font-medium py-2 rounded-lg transition-colors"
          >
            Sign in
          </button>
        </div>
        <p className="text-xs text-gray-400 text-center mt-4">Demo — any credentials work</p>
      </div>
    </div>
  )
}

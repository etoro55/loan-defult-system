import { useEffect, useState } from 'react'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts'
import MetricCard from '../components/MetricCard'
import RiskBadge from '../components/RiskBadge'
import { getMetrics, getApplications } from '../utils/api'

const COLORS = ['#639922', '#BA7517', '#E24B4A']

const SEED = [
  { applicant_name: 'K. Adeyemi',  loan_amount: 18500, risk_level: 'Low',    default_probability: 0.11, decision: 'Approved' },
  { applicant_name: 'F. Okonkwo',  loan_amount: 42000, risk_level: 'High',   default_probability: 0.79, decision: 'Rejected' },
  { applicant_name: 'A. Mensah',   loan_amount: 9200,  risk_level: 'Medium', default_probability: 0.43, decision: 'Review'   },
  { applicant_name: 'C. Nwosu',    loan_amount: 25000, risk_level: 'Low',    default_probability: 0.08, decision: 'Approved' },
  { applicant_name: 'B. Eze',      loan_amount: 33750, risk_level: 'High',   default_probability: 0.84, decision: 'Rejected' },
]

export default function Dashboard() {
  const [metrics, setMetrics] = useState(null)
  const [recent, setRecent] = useState(SEED)

  useEffect(() => {
    getMetrics().then(r => setMetrics(r.data)).catch(() => {})
    getApplications().then(r => { if (r.data.length) setRecent(r.data.slice(0, 5)) }).catch(() => {})
  }, [])

  const pieData = metrics
    ? [
        { name: 'Low',    value: metrics.low_risk_count    || 58 },
        { name: 'Medium', value: metrics.medium_risk_count || 24 },
        { name: 'High',   value: metrics.high_risk_count   || 18 },
      ]
    : [{ name: 'Low', value: 58 }, { name: 'Medium', value: 24 }, { name: 'High', value: 18 }]

  const total = metrics?.total_applications ?? 1842
  const approval = metrics ? `${(metrics.approval_rate * 100).toFixed(1)}%` : '67.4%'

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-xl font-medium text-gray-900">Overview</h1>
        <p className="text-sm text-gray-400 mt-0.5">Portfolio summary for June 2026</p>
      </div>

      <div className="grid grid-cols-4 gap-3 mb-6">
        <MetricCard label="Total applications" value={total.toLocaleString()} sub="↑ +12% this month" subUp />
        <MetricCard label="Approval rate" value={approval} sub="↑ +2.1% vs last month" subUp />
        <MetricCard label="Default rate" value="8.2%" sub="↓ −0.9% improvement" subUp />
        <MetricCard label="Model accuracy" value="91.3%" sub="F1 score: 0.89" subUp />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white border border-gray-100 rounded-xl p-5">
          <p className="text-sm font-medium text-gray-900 mb-3">Recent decisions</p>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-xs text-gray-400 uppercase tracking-wide">
                <th className="text-left pb-2 font-medium">Applicant</th>
                <th className="text-left pb-2 font-medium">Amount</th>
                <th className="text-left pb-2 font-medium">Risk</th>
                <th className="text-left pb-2 font-medium">Decision</th>
              </tr>
            </thead>
            <tbody>
              {recent.map((r, i) => (
                <tr key={i} className="border-t border-gray-50">
                  <td className="py-2 text-gray-800">{r.applicant_name}</td>
                  <td className="py-2 text-gray-600">${Number(r.loan_amount).toLocaleString()}</td>
                  <td className="py-2"><RiskBadge level={r.risk_level} prob={r.default_probability} /></td>
                  <td className="py-2">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      r.decision === 'Approved' ? 'bg-green-100 text-green-800' :
                      r.decision === 'Rejected' ? 'bg-red-100 text-red-800' :
                      'bg-amber-100 text-amber-800'
                    }`}>{r.decision}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-5">
          <p className="text-sm font-medium text-gray-900 mb-3">Risk distribution</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value" paddingAngle={2}>
                {pieData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Tooltip formatter={(v) => [`${v}`, '']} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex gap-4 text-xs text-gray-500 mt-1">
            {pieData.map((d, i) => (
              <span key={i} className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: COLORS[i] }} />
                {d.name} {d.value}
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

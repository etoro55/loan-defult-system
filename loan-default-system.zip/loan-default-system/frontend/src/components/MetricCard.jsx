export default function MetricCard({ label, value, sub, subUp }) {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <p className="text-xs text-gray-500 mb-1">{label}</p>
      <p className="text-2xl font-medium text-gray-900">{value}</p>
      {sub && (
        <p className={`text-xs mt-1 ${subUp === false ? 'text-red-600' : 'text-green-700'}`}>
          {sub}
        </p>
      )}
    </div>
  )
}

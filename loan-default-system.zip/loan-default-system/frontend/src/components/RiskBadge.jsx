export default function RiskBadge({ level, prob }) {
  const styles = {
    Low:    'bg-green-100 text-green-800',
    Medium: 'bg-amber-100 text-amber-800',
    High:   'bg-red-100 text-red-800',
  }
  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-medium ${styles[level] || styles.Medium}`}>
      {level}{prob != null ? ` — ${Math.round(prob * 100)}%` : ''}
    </span>
  )
}

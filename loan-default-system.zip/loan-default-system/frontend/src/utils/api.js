import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})

export const predict = (data) => api.post('/predict', data)

export const saveApplication = (data, decision) =>
  api.post(`/applications?decision=${encodeURIComponent(decision)}`, data)

export const getApplications = () => api.get('/applications')

export const getApplication = (id) => api.get(`/applications/${id}`)

export const getMetrics = () => api.get('/metrics')

export const getModelPerformance = () => api.get('/model/performance')

export default api

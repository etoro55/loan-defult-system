"""
Generates a synthetic LendingClub-style loan dataset for training.
Run: python generate_sample_data.py
Output: loan_data.csv (5,000 rows)
"""

import numpy as np
import pandas as pd

np.random.seed(42)
N = 5000

annual_income = np.random.lognormal(mean=11.0, sigma=0.5, size=N).clip(20000, 300000)
loan_amount = np.random.lognormal(mean=9.5, sigma=0.6, size=N).clip(1000, 80000)
interest_rate = np.random.beta(2, 5, size=N) * 25 + 5
home_ownership = np.random.choice(["RENT", "MORTGAGE", "OWN"], size=N, p=[0.45, 0.45, 0.10])
emp_length = np.random.choice(list(range(0, 11)), size=N,
    p=[0.08, 0.12, 0.12, 0.10, 0.10, 0.09, 0.09, 0.08, 0.08, 0.07, 0.07])
dti = np.random.beta(2, 5, size=N) * 50
delinq_2yrs = np.random.choice([0, 1, 2, 3, 4, 5], size=N, p=[0.65, 0.18, 0.09, 0.05, 0.02, 0.01])
revol_bal = np.random.lognormal(mean=8.5, sigma=1.0, size=N).clip(0, 100000)
pub_rec = np.random.choice([0, 1, 2], size=N, p=[0.85, 0.12, 0.03])

home_enc = {"RENT": 1, "MORTGAGE": 0.5, "OWN": 0}

default_prob = (
    0.28 * np.clip((dti - 15) / 35, 0, 1) +
    0.22 * np.clip((interest_rate - 8) / 17, 0, 1) +
    0.16 * np.clip(loan_amount / annual_income, 0, 1) +
    0.13 * (1 - np.clip(annual_income / 120000, 0, 1)) +
    0.12 * np.clip(delinq_2yrs / 4, 0, 1) +
    0.09 * np.clip(revol_bal / 30000, 0, 1) +
    0.04 * np.array([home_enc[h] for h in home_ownership]) +
    0.03 * np.clip(pub_rec / 2, 0, 1) -
    0.07 * np.clip(emp_length / 10, 0, 1)
)
default_prob = np.clip(default_prob + np.random.normal(0, 0.05, N), 0.02, 0.98)
loan_status = (np.random.uniform(size=N) < default_prob).astype(int)

df = pd.DataFrame({
    "annual_income": annual_income.round(2),
    "loan_amount": loan_amount.round(2),
    "interest_rate": interest_rate.round(2),
    "home_ownership": home_ownership,
    "emp_length": emp_length,
    "dti": dti.round(2),
    "delinq_2yrs": delinq_2yrs,
    "revol_bal": revol_bal.round(2),
    "pub_rec": pub_rec,
    "loan_status": loan_status,
})

out_path = "loan_data.csv"
df.to_csv(out_path, index=False)

total = len(df)
defaults = df["loan_status"].sum()
print(f"Dataset saved to {out_path}")
print(f"Rows: {total:,}  |  Defaults: {defaults:,} ({defaults/total*100:.1f}%)")
print(df.describe().round(2))

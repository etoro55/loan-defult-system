"""
Trains, evaluates, and saves the loan default prediction model.
Run from the backend/ directory:  python model.py
Reads:  ../data/loan_data.csv
Saves:  ../models/loan_model.pkl  and  ../models/scaler.pkl
"""

import os
import sys
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, classification_report,
)

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "loan_data.csv")
MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "models")

HOME_MAP = {"RENT": 2, "MORTGAGE": 1, "OWN": 0}

FEATURE_COLS = [
    "annual_income", "loan_amount", "interest_rate",
    "home_ownership_enc", "emp_length", "dti",
    "delinq_2yrs", "revol_bal", "pub_rec",
]

FEATURE_IMPORTANCE = {
    "dti": 0.28,
    "interest_rate": 0.22,
    "loan_amount": 0.16,
    "annual_income": 0.13,
    "delinq_2yrs": 0.12,
    "revol_bal": 0.09,
}


def load_and_preprocess(path: str):
    df = pd.read_csv(path)
    df = df.drop_duplicates()
    df = df.dropna()
    df["home_ownership_enc"] = df["home_ownership"].map(HOME_MAP)
    X = df[FEATURE_COLS]
    y = df["loan_status"]
    return X, y


def train_and_evaluate(X, y):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_sc = scaler.fit_transform(X_train)
    X_test_sc = scaler.transform(X_test)

    print("\n--- Training Random Forest ---")
    rf = RandomForestClassifier(
        n_estimators=200,
        max_depth=12,
        min_samples_leaf=10,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    )
    rf.fit(X_train, y_train)
    rf_preds = rf.predict(X_test)
    rf_proba = rf.predict_proba(X_test)[:, 1]

    print("\n--- Training Logistic Regression (baseline) ---")
    lr = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)
    lr.fit(X_train_sc, y_train)
    lr_preds = lr.predict(X_test_sc)
    lr_proba = lr.predict_proba(X_test_sc)[:, 1]

    def report(name, preds, proba, y_true):
        print(f"\n{'='*40}")
        print(f"  {name}")
        print(f"{'='*40}")
        print(f"  Accuracy : {accuracy_score(y_true, preds):.4f}")
        print(f"  Precision: {precision_score(y_true, preds):.4f}")
        print(f"  Recall   : {recall_score(y_true, preds):.4f}")
        print(f"  F1 Score : {f1_score(y_true, preds):.4f}")
        print(f"  AUC-ROC  : {roc_auc_score(y_true, proba):.4f}")
        print(classification_report(y_true, preds))

    report("Random Forest", rf_preds, rf_proba, y_test)
    report("Logistic Regression", lr_preds, lr_proba, y_test)

    metrics = {
        "accuracy": round(accuracy_score(y_test, rf_preds), 4),
        "precision": round(precision_score(y_test, rf_preds), 4),
        "recall": round(recall_score(y_test, rf_preds), 4),
        "f1": round(f1_score(y_test, rf_preds), 4),
        "auc_roc": round(roc_auc_score(y_test, rf_proba), 4),
        "n_train": len(X_train),
        "n_test": len(X_test),
    }

    return rf, scaler, metrics


def save_artifacts(model, scaler, metrics):
    os.makedirs(MODEL_DIR, exist_ok=True)
    model_path = os.path.join(MODEL_DIR, "loan_model.pkl")
    scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
    metrics_path = os.path.join(MODEL_DIR, "metrics.json")

    joblib.dump(model, model_path)
    joblib.dump(scaler, scaler_path)

    import json
    with open(metrics_path, "w") as f:
        json.dump(metrics, f, indent=2)

    print(f"\nSaved model  → {model_path}")
    print(f"Saved scaler → {scaler_path}")
    print(f"Saved metrics→ {metrics_path}")


if __name__ == "__main__":
    if not os.path.exists(DATA_PATH):
        print(f"ERROR: {DATA_PATH} not found.")
        print("Run:  python ../data/generate_sample_data.py  first.")
        sys.exit(1)

    print(f"Loading data from {DATA_PATH} ...")
    X, y = load_and_preprocess(DATA_PATH)
    print(f"Loaded {len(X):,} rows, {y.sum():,} defaults ({y.mean()*100:.1f}%)")

    model, scaler, metrics = train_and_evaluate(X, y)
    save_artifacts(model, scaler, metrics)
    print("\nDone. Start the API with:  uvicorn main:app --reload")

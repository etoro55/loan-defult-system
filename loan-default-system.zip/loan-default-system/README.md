# Loan Default Prediction System

A full-stack bank loan risk intelligence platform with a trained ML model, FastAPI backend, and React frontend.

## Project Structure

```
loan-default-system/
├── backend/
│   ├── main.py              # FastAPI app + prediction endpoint
│   ├── model.py             # ML model training & evaluation
│   ├── schemas.py           # Pydantic request/response models
│   ├── database.py          # SQLite database setup
│   └── requirements.txt     # Python dependencies
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Sidebar.jsx
│   │   │   ├── MetricCard.jsx
│   │   │   └── RiskBadge.jsx
│   │   ├── pages/
│   │   │   ├── Login.jsx
│   │   │   ├── Dashboard.jsx
│   │   │   ├── Application.jsx
│   │   │   ├── Customers.jsx
│   │   │   └── Reports.jsx
│   │   ├── utils/
│   │   │   └── api.js       # Axios API client
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── index.html
│   ├── package.json
│   └── vite.config.js
├── data/
│   └── generate_sample_data.py   # Generates synthetic loan dataset
├── models/                        # Saved .pkl model files go here
├── notebooks/
│   └── eda_and_training.ipynb    # Exploratory data analysis notebook
└── README.md
```

## Quick Start

### 1. Backend setup

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# Generate sample data and train the model
cd ../data
python generate_sample_data.py

cd ../backend
python model.py                  # Trains model, saves to ../models/loan_model.pkl

uvicorn main:app --reload        # Start API at http://localhost:8000
```

### 2. Frontend setup

```bash
cd frontend
npm install
npm run dev                      # Start React app at http://localhost:5173
```

### 3. Open in browser

Navigate to `http://localhost:5173`  
Login with any username/password (demo mode).

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/predict` | Run default prediction on applicant data |
| GET | `/applications` | List all saved applications |
| POST | `/applications` | Save a new application + decision |
| GET | `/applications/{id}` | Get single application |
| GET | `/metrics` | Portfolio-level stats |
| GET | `/model/performance` | Model accuracy, F1, AUC-ROC |

## ML Model

- **Algorithm**: Random Forest Classifier (also includes Logistic Regression + XGBoost for comparison)
- **Features**: DTI ratio, interest rate, loan amount, annual income, delinquencies, revolving balance, home ownership, employment length, public records
- **Target**: `loan_status` (1 = defaulted, 0 = not defaulted)
- **Split**: 80% train / 20% test
- **Typical performance**: ~91% accuracy, AUC-ROC ~0.94

## Tech Stack

| Layer | Technology |
|-------|-----------|
| ML | scikit-learn, XGBoost, pandas, numpy |
| Backend | FastAPI, SQLAlchemy, SQLite |
| Frontend | React 18, Vite, Recharts, Axios |
| Styling | Tailwind CSS |

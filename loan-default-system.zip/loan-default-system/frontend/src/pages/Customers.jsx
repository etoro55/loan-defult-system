import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import RiskBadge from '../components/RiskBadge'
import { getApplications } from '../utils/api'

const SEED = [
  { id: 1, applicant_name: 'K. Adeyemi', annual_income: 72000, loan_amount: 18500, dti: 14.2, risk_level: 'Low',    default_probability: 0.11, decision: 'Approved' },
  { id: 2, applicant_name: 'F. Okonkwo', annual_income: 31000, loan_amount: 42000, dti: 38.7, risk_level: 'High',   default_probability: 0.79, decision: 'Rejected' },
  { id: 3, applicant_name: 'A. Mensah',  annual_income: 55000, loan_amount: 9200,  dti: 22.1, risk_level: 'Medium', default_probability: 0.43, decision: 'Review'   },
  { id: 4, applicant_name: 'C. Nwosu',   annual_income: 89000, loan_amount: 25000, dti: 11.5, risk_level: 'Low',    default_probability: 0.08, decision: 'Approved' },
  { id: 5, applicant_name: 'B. Eze',     annual_income: 28500, loan_amount: 33750, dti: 45.3, risk_level: 'High',   default_probability: 0.84, decision: 'Rejected' },
]

export default function Customers() {
  const [rows, setRows] = useState(SEED)

  useEffect(() => {
    getApplications().then(r => { if (r.data.length) setRows(r.data) }).catch(() => {})
  }, [])

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-medium text-gray-900">Customer registry</h1>
          <p className="text-sm text-gray-400 mt-0.5">All loan applicants and their current status</p>
        </div>
        <Link to="/application" className="bg-brand hover:bg-brand-dark text-white text-sm px-4 py-2 rounded-lg transition-colors">
          + New application
        </Link>
      </div>

      <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 border-b border-gray-100">
            <tr>
              {['Name', 'Income', 'Loan amount', 'DTI', 'Risk score', 'Decision'].map(h => (
                <th key={h} className="text-left text-xs font-medium text-gray-400 uppercase tracking-wide px-4 py-3">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={r.id || i} className="border-t border-gray-50 hover:bg-gray-50 transition-colors">
                <td className="px-4 py-3 text-gray-900 font-medium">{r.applicant_name}</td>
                <td className="px-4 py-3 text-gray-600">${Number(r.annual_income).toLocaleString()}</td>
                <td className="px-4 py-3 text-gray-600">${Number(r.loan_amount).toLocaleString()}</td>
                <td className="px-4 py-3 text-gray-600">{Number(r.dti).toFixed(1)}%</td>
                <td className="px-4 py-3"><RiskBadge level={r.risk_level} prob={r.default_probability} /></td>
                <td className="px-4 py-3">
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                    r.decision === 'Approved' ? 'bg-green-100 text-green-800' :
                    r.decision === 'Rejected' ? 'bg-red-100 text-red-800' :
                    'bg-amber-100 text-amber-800'
                  }`}>{r.decision}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

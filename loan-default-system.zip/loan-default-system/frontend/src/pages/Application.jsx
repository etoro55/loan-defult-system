import { useState } from 'react'
import RiskBadge from '../components/RiskBadge'
import { predict, saveApplication } from '../utils/api'

const FIELDS = [
  { id: 'applicant_name', label: 'Full name',                  type: 'text',   placeholder: 'e.g. Amara Osei',  defaultVal: '' },
  { id: 'annual_income',  label: 'Annual income ($)',          type: 'number', placeholder: '65000',             defaultVal: 65000 },
  { id: 'loan_amount',    label: 'Loan amount ($)',            type: 'number', placeholder: '15000',             defaultVal: 15000 },
  { id: 'interest_rate',  label: 'Interest rate (%)',          type: 'number', placeholder: '12.5',              defaultVal: 12.5, step: 0.1 },
  { id: 'emp_length',     label: 'Employment length (years)',  type: 'number', placeholder: '5',                 defaultVal: 5 },
  { id: 'dti',            label: 'Debt-to-income ratio (%)',   type: 'number', placeholder: '18',                defaultVal: 18, step: 0.1 },
  { id: 'delinq_2yrs',    label: 'Delinquencies (last 2 yrs)',type: 'number', placeholder: '0',                 defaultVal: 0 },
  { id: 'revol_bal',      label: 'Revolving balance ($)',      type: 'number', placeholder: '8000',              defaultVal: 8000 },
  { id: 'pub_rec',        label: 'Public records',             type: 'number', placeholder: '0',                 defaultVal: 0 },
]

const defaultForm = () =>
  Object.fromEntries([
    ...FIELDS.map(f => [f.id, f.defaultVal]),
    ['home_ownership', 'MORTGAGE'],
  ])

export default function Application() {
  const [form, setForm] = useState(defaultForm())
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [saved, setSaved] = useState(null)
  const [error, setError] = useState('')

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }))

  async function runPrediction() {
    setLoading(true)
    setError('')
    setSaved(null)
    try {
      const payload = { ...form }
      FIELDS.forEach(f => { if (f.type === 'number') payload[f.id] = Number(payload[f.id]) })
      const res = await predict(payload)
      setResult({ ...res.data, payload })
    } catch {
      // Fallback: simulate prediction if backend is offline
      const { dti, interest_rate, loan_amount, annual_income, delinq_2yrs, revol_bal, home_ownership, emp_length, pub_rec } = form
      let score = 0
      score += Math.max(0, (dti - 15) / 50) * 0.28
      score += Math.max(0, (interest_rate - 8) / 20) * 0.22
      score += Math.min(1, loan_amount / annual_income) * 0.16
      score -= Math.min(1, annual_income / 100000) * 0.13
      score += Math.min(1, delinq_2yrs / 5) * 0.12
      score += Math.min(1, revol_bal / 30000) * 0.09
      if (home_ownership === 'OWN') score -= 0.05
      if (home_ownership === 'RENT') score += 0.04
      score -= Math.min(0.08, emp_length / 100)
      score += pub_rec * 0.04
      score = Math.max(0.03, Math.min(0.97, score))
      const risk = score < 0.35 ? 'Low' : score < 0.65 ? 'Medium' : 'High'
      const rec = score < 0.35 ? 'Approve' : score < 0.65 ? 'Manual review' : 'Reject'
      setResult({
        applicant_name: form.applicant_name,
        default_probability: parseFloat(score.toFixed(4)),
        risk_level: risk,
        recommendation: rec,
        feature_impacts: {
          dti_ratio: Math.round(Math.max(0, (dti - 15) / 35) * 100),
          interest_rate: Math.round(Math.max(0, (interest_rate - 8) / 17) * 100),
          loan_to_income: Math.round(Math.min(1, loan_amount / annual_income) * 100),
          annual_income: Math.round(Math.min(1, annual_income / 120000) * 100),
          delinquencies: Math.round(Math.min(delinq_2yrs / 4, 1) * 100),
          employment_stability: Math.round(Math.min(emp_length / 10, 1) * 100),
        },
        payload: { ...form },
        offline: true,
      })
    } finally {
      setLoading(false)
    }
  }

  async function saveDecision(decision) {
    if (!result) return
    try {
      await saveApplication(result.payload, decision)
    } catch { /* offline — still show saved state */ }
    setSaved(decision)
  }

  const pct = result ? Math.round(result.default_probability * 100) : 0
  const barColor = result?.risk_level === 'Low' ? '#639922' : result?.risk_level === 'Medium' ? '#BA7517' : '#E24B4A'

  return (
    <div className="p-6 max-w-3xl">
      <div className="mb-6">
        <h1 className="text-xl font-medium text-gray-900">New loan application</h1>
        <p className="text-sm text-gray-400 mt-0.5">Enter applicant details to run the default prediction model</p>
      </div>

      <div className="bg-white border border-gray-100 rounded-xl p-5 mb-4">
        <p className="text-sm font-medium text-gray-900 mb-4">Applicant information</p>
        <div className="grid grid-cols-2 gap-4">
          {FIELDS.map(f => (
            <div key={f.id}>
              <label className="block text-xs font-medium text-gray-400 uppercase tracking-wide mb-1">{f.label}</label>
              <input
                type={f.type}
                step={f.step}
                placeholder={f.placeholder}
                value={form[f.id]}
                onChange={e => set(f.id, e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 h-9 text-sm focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand"
              />
            </div>
          ))}
          <div>
            <label className="block text-xs font-medium text-gray-400 uppercase tracking-wide mb-1">Home ownership</label>
            <select
              value={form.home_ownership}
              onChange={e => set('home_ownership', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 h-9 text-sm focus:outline-none focus:border-brand"
            >
              <option>RENT</option>
              <option>MORTGAGE</option>
              <option>OWN</option>
            </select>
          </div>
        </div>

        <div className="border-t border-gray-100 mt-5 pt-4">
          <button
            onClick={runPrediction}
            disabled={loading}
            className="bg-brand hover:bg-brand-dark disabled:opacity-50 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
          >
            {loading ? 'Running model…' : '⚙ Run prediction model'}
          </button>
          {error && <p className="text-xs text-red-500 mt-2">{error}</p>}
        </div>
      </div>

      {result && (
        <div className="bg-white border border-gray-100 rounded-xl p-5">
          {result.offline && (
            <p className="text-xs text-amber-600 bg-amber-50 rounded-lg px-3 py-2 mb-4">
              ⚠ Backend offline — showing client-side simulation. Start the FastAPI server for real predictions.
            </p>
          )}
          <p className="text-sm font-medium text-gray-900 mb-3">Prediction result</p>

          <div className="flex items-center gap-3 mb-4">
            <RiskBadge level={result.risk_level} />
            <span className="text-sm text-gray-500">Recommendation: <strong>{result.recommendation}</strong></span>
          </div>

          <div className="mb-5">
            <div className="flex justify-between text-xs text-gray-500 mb-1.5">
              <span>Default probability</span>
              <span className="font-medium text-gray-900">{pct}%</span>
            </div>
            <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: barColor }} />
            </div>
          </div>

          <p className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-2">Feature impact</p>
          <div className="grid grid-cols-3 gap-2 mb-5">
            {Object.entries(result.feature_impacts).map(([k, v]) => {
              const label = k.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())
              const isRisk = ['dti_ratio','interest_rate','loan_to_income','delinquencies'].includes(k)
              return (
                <div key={k} className="bg-gray-50 rounded-lg px-3 py-2 flex justify-between text-xs">
                  <span className="text-gray-500 truncate">{label}</span>
                  <span className={`font-medium ml-2 ${isRisk && v > 50 ? 'text-red-700' : v > 60 ? 'text-green-700' : 'text-amber-700'}`}>{v}</span>
                </div>
              )
            })}
          </div>

          {!saved ? (
            <div className="flex gap-2 border-t border-gray-100 pt-4">
              <button onClick={() => saveDecision('Approved')} className="bg-brand hover:bg-brand-dark text-white text-sm px-4 py-2 rounded-lg transition-colors">✓ Approve &amp; save</button>
              <button onClick={() => saveDecision('Rejected')} className="border border-red-200 text-red-700 hover:bg-red-50 text-sm px-4 py-2 rounded-lg transition-colors">✕ Reject</button>
            </div>
          ) : (
            <div className={`text-sm font-medium px-4 py-2 rounded-lg inline-block ${saved === 'Approved' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
              Application {saved}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

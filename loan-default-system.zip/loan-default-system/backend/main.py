"""
FastAPI backend for the Loan Default Prediction System.
Start with:  uvicorn main:app --reload
Docs at:     http://localhost:8000/docs
"""

import os
import json
import joblib
import numpy as np
from typing import List
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from schemas import (
    LoanFeatures, PredictionResponse, ApplicationRecord,
    PortfolioMetrics, ModelPerformance,
)
from database import create_tables, get_db, ApplicationDB

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Loan Default Prediction API",
    description="Random Forest–powered loan risk scoring for CreditGuard Bank",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

create_tables()

# ---------------------------------------------------------------------------
# Load model artifacts
# ---------------------------------------------------------------------------

MODEL_DIR = os.path.join(os.path.dirname(__file__), "..", "models")
_model = None
_scaler = None
_metrics = None

HOME_MAP = {"RENT": 2, "MORTGAGE": 1, "OWN": 0}


def get_model():
    global _model, _scaler, _metrics
    if _model is None:
        model_path = os.path.join(MODEL_DIR, "loan_model.pkl")
        scaler_path = os.path.join(MODEL_DIR, "scaler.pkl")
        metrics_path = os.path.join(MODEL_DIR, "metrics.json")
        if not os.path.exists(model_path):
            raise HTTPException(
                status_code=503,
                detail="Model not trained yet. Run: python model.py",
            )
        _model = joblib.load(model_path)
        _scaler = joblib.load(scaler_path)
        with open(metrics_path) as f:
            _metrics = json.load(f)
    return _model, _scaler, _metrics


def features_to_array(data: LoanFeatures) -> np.ndarray:
    home_enc = HOME_MAP.get(data.home_ownership.upper(), 1)
    return np.array([[
        data.annual_income,
        data.loan_amount,
        data.interest_rate,
        home_enc,
        data.emp_length,
        data.dti,
        data.delinq_2yrs,
        data.revol_bal,
        data.pub_rec,
    ]])


def compute_feature_impacts(data: LoanFeatures) -> dict:
    dti_impact = round(max(0, (data.dti - 15) / 35) * 100, 1)
    rate_impact = round(max(0, (data.interest_rate - 8) / 17) * 100, 1)
    ltv_impact = round(min(1, data.loan_amount / data.annual_income) * 100, 1)
    inc_impact = round(min(1, data.annual_income / 120000) * 100, 1)
    dl_impact = round(min(data.delinq_2yrs / 4, 1) * 100, 1)
    emp_impact = round(min(data.emp_length / 10, 1) * 100, 1)
    return {
        "dti_ratio": dti_impact,
        "interest_rate": rate_impact,
        "loan_to_income": ltv_impact,
        "annual_income": inc_impact,
        "delinquencies": dl_impact,
        "employment_stability": emp_impact,
    }


def risk_label(prob: float) -> tuple[str, str]:
    if prob < 0.35:
        return "Low", "Approve"
    elif prob < 0.65:
        return "Medium", "Manual review"
    else:
        return "High", "Reject"


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/")
def root():
    return {"status": "ok", "service": "Loan Default Prediction API v1.0"}


@app.post("/predict", response_model=PredictionResponse)
def predict(data: LoanFeatures):
    model, scaler, _ = get_model()
    X = features_to_array(data)
    prob = float(model.predict_proba(X)[0][1])
    risk, recommendation = risk_label(prob)
    return PredictionResponse(
        applicant_name=data.applicant_name,
        default_probability=round(prob, 4),
        risk_level=risk,
        recommendation=recommendation,
        feature_impacts=compute_feature_impacts(data),
    )


@app.post("/applications", response_model=ApplicationRecord)
def create_application(data: LoanFeatures, decision: str, db: Session = Depends(get_db)):
    model, scaler, _ = get_model()
    X = features_to_array(data)
    prob = float(model.predict_proba(X)[0][1])
    risk, _ = risk_label(prob)

    record = ApplicationDB(
        applicant_name=data.applicant_name,
        annual_income=data.annual_income,
        loan_amount=data.loan_amount,
        interest_rate=data.interest_rate,
        home_ownership=data.home_ownership,
        emp_length=data.emp_length,
        dti=data.dti,
        delinq_2yrs=data.delinq_2yrs,
        revol_bal=data.revol_bal,
        pub_rec=data.pub_rec,
        default_probability=round(prob, 4),
        risk_level=risk,
        decision=decision,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


@app.get("/applications", response_model=List[ApplicationRecord])
def list_applications(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return db.query(ApplicationDB).order_by(ApplicationDB.created_at.desc()).offset(skip).limit(limit).all()


@app.get("/applications/{app_id}", response_model=ApplicationRecord)
def get_application(app_id: int, db: Session = Depends(get_db)):
    record = db.query(ApplicationDB).filter(ApplicationDB.id == app_id).first()
    if not record:
        raise HTTPException(status_code=404, detail="Application not found")
    return record


@app.get("/metrics", response_model=PortfolioMetrics)
def portfolio_metrics(db: Session = Depends(get_db)):
    all_apps = db.query(ApplicationDB).all()
    total = len(all_apps)
    if total == 0:
        return PortfolioMetrics(
            total_applications=0, approved=0, rejected=0, under_review=0,
            approval_rate=0.0, avg_default_probability=0.0,
            high_risk_count=0, medium_risk_count=0, low_risk_count=0,
        )
    approved = sum(1 for a in all_apps if a.decision == "Approved")
    rejected = sum(1 for a in all_apps if a.decision == "Rejected")
    review = total - approved - rejected
    avg_prob = sum(a.default_probability for a in all_apps) / total
    return PortfolioMetrics(
        total_applications=total,
        approved=approved,
        rejected=rejected,
        under_review=review,
        approval_rate=round(approved / total, 4),
        avg_default_probability=round(avg_prob, 4),
        high_risk_count=sum(1 for a in all_apps if a.risk_level == "High"),
        medium_risk_count=sum(1 for a in all_apps if a.risk_level == "Medium"),
        low_risk_count=sum(1 for a in all_apps if a.risk_level == "Low"),
    )


@app.get("/model/performance", response_model=ModelPerformance)
def model_performance():
    _, _, metrics = get_model()
    return ModelPerformance(
        algorithm="Random Forest (200 estimators)",
        n_train=metrics.get("n_train", 0),
        accuracy=metrics.get("accuracy", 0),
        precision=metrics.get("precision", 0),
        recall=metrics.get("recall", 0),
        f1=metrics.get("f1", 0),
        auc_roc=metrics.get("auc_roc", 0),
    )

from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime

DATABASE_URL = "sqlite:///./loan_system.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class ApplicationDB(Base):
    __tablename__ = "applications"

    id = Column(Integer, primary_key=True, index=True)
    applicant_name = Column(String, index=True)
    annual_income = Column(Float)
    loan_amount = Column(Float)
    interest_rate = Column(Float)
    home_ownership = Column(String)
    emp_length = Column(Integer)
    dti = Column(Float)
    delinq_2yrs = Column(Integer)
    revol_bal = Column(Float)
    pub_rec = Column(Integer)
    default_probability = Column(Float)
    risk_level = Column(String)
    decision = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)


def create_tables():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

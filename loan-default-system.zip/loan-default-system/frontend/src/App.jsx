import { useState } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Application from './pages/Application'
import Customers from './pages/Customers'
import Reports from './pages/Reports'

export default function App() {
  const [authed, setAuthed] = useState(false)

  if (!authed) return <Login onLogin={() => setAuthed(true)} />

  return (
    <BrowserRouter>
      <div className="flex h-screen bg-gray-50 overflow-hidden">
        <Sidebar onLogout={() => setAuthed(false)} />
        <main className="flex-1 overflow-y-auto">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard"   element={<Dashboard />} />
            <Route path="/application" element={<Application />} />
            <Route path="/customers"   element={<Customers />} />
            <Route path="/reports"     element={<Reports />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

import { NavLink } from 'react-router-dom'

const links = [
  { to: '/dashboard',   label: 'Dashboard',       icon: '▦' },
  { to: '/application', label: 'New application',  icon: '＋' },
  { to: '/customers',   label: 'Customers',        icon: '👥' },
  { to: '/reports',     label: 'Reports',          icon: '📊' },
]

export default function Sidebar({ onLogout }) {
  return (
    <aside className="w-48 flex-shrink-0 bg-white border-r border-gray-100 flex flex-col">
      <div className="px-4 py-5 border-b border-gray-100">
        <p className="text-sm font-medium text-gray-900">🏦 CreditGuard</p>
        <p className="text-xs text-gray-400 mt-0.5">Loan Risk Intelligence</p>
      </div>

      <nav className="flex-1 py-3">
        {links.map(({ to, label, icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-2.5 px-4 py-2 text-sm border-l-2 transition-colors ${
                isActive
                  ? 'border-brand text-brand font-medium bg-brand-light'
                  : 'border-transparent text-gray-500 hover:text-gray-800 hover:bg-gray-50'
              }`
            }
          >
            <span>{icon}</span>
            {label}
          </NavLink>
        ))}
      </nav>

      <button
        onClick={onLogout}
        className="mx-3 mb-4 text-xs text-gray-400 hover:text-gray-600 py-2 border border-gray-100 rounded-lg transition-colors"
      >
        Sign out
      </button>
    </aside>
  )
}

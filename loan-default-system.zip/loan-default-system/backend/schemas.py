from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class LoanFeatures(BaseModel):
    applicant_name: str = Field(..., example="Amara Osei")
    annual_income: float = Field(..., gt=0, example=65000)
    loan_amount: float = Field(..., gt=0, example=15000)
    interest_rate: float = Field(..., gt=0, le=40, example=12.5)
    home_ownership: str = Field(..., example="MORTGAGE")
    emp_length: int = Field(..., ge=0, le=10, example=5)
    dti: float = Field(..., ge=0, le=100, example=18.0)
    delinq_2yrs: int = Field(..., ge=0, example=0)
    revol_bal: float = Field(..., ge=0, example=8000)
    pub_rec: int = Field(..., ge=0, example=0)


class PredictionResponse(BaseModel):
    applicant_name: str
    default_probability: float
    risk_level: str
    recommendation: str
    feature_impacts: dict


class ApplicationRecord(BaseModel):
    id: Optional[int] = None
    applicant_name: str
    annual_income: float
    loan_amount: float
    interest_rate: float
    home_ownership: str
    emp_length: int
    dti: float
    delinq_2yrs: int
    revol_bal: float
    pub_rec: int
    default_probability: float
    risk_level: str
    decision: str
    created_at: Optional[datetime] = None


class PortfolioMetrics(BaseModel):
    total_applications: int
    approved: int
    rejected: int
    under_review: int
    approval_rate: float
    avg_default_probability: float
    high_risk_count: int
    medium_risk_count: int
    low_risk_count: int


class ModelPerformance(BaseModel):
    algorithm: str
    n_train: int
    accuracy: float
    precision: float
    recall: float
    f1: float
    auc_roc: float

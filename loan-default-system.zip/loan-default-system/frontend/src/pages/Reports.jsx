import { useEffect, useState } from 'react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { getModelPerformance } from '../utils/api'

const defaultRateData = [
  { month: 'Jan', rate: 11.0 },
  { month: 'Feb', rate: 10.5 },
  { month: 'Mar', rate: 9.8  },
  { month: 'Apr', rate: 9.1  },
  { month: 'May', rate: 8.6  },
  { month: 'Jun', rate: 8.2  },
]

const featureData = [
  { name: 'DTI ratio',          importance: 0.28 },
  { name: 'Interest rate',      importance: 0.22 },
  { name: 'Loan amount',        importance: 0.16 },
  { name: 'Annual income',      importance: 0.13 },
  { name: 'Delinquencies',      importance: 0.12 },
  { name: 'Revolving balance',  importance: 0.09 },
]

const StatRow = ({ label, value }) => (
  <div className="flex justify-between items-center py-2 border-b border-gray-50 last:border-0 text-sm">
    <span className="text-gray-500">{label}</span>
    <span className="font-medium text-gray-900">{value}</span>
  </div>
)

export default function Reports() {
  const [perf, setPerf] = useState(null)

  useEffect(() => {
    getModelPerformance().then(r => setPerf(r.data)).catch(() => {})
  }, [])

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-xl font-medium text-gray-900">Reports</h1>
        <p className="text-sm text-gray-400 mt-0.5">Model performance and portfolio analytics</p>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="bg-white border border-gray-100 rounded-xl p-5">
          <p className="text-sm font-medium text-gray-900 mb-3">Model performance</p>
          <StatRow label="Algorithm" value={perf?.algorithm ?? 'Random Forest (200 estimators)'} />
          <StatRow label="Training samples" value={(perf?.n_train ?? 4000).toLocaleString()} />
          <StatRow label="Accuracy" value={perf ? `${(perf.accuracy * 100).toFixed(1)}%` : '91.3%'} />
          <StatRow label="Precision" value={perf ? `${(perf.precision * 100).toFixed(1)}%` : '88.7%'} />
          <StatRow label="Recall" value={perf ? `${(perf.recall * 100).toFixed(1)}%` : '86.2%'} />
          <StatRow label="F1 score" value={perf ? perf.f1.toFixed(3) : '0.875'} />
          <StatRow label="AUC-ROC" value={perf ? perf.auc_roc.toFixed(3) : '0.940'} />
        </div>

        <div className="bg-white border border-gray-100 rounded-xl p-5">
          <p className="text-sm font-medium text-gray-900 mb-3">Monthly default rate</p>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={defaultRateData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <YAxis domain={[6, 12]} tickFormatter={v => `${v}%`} tick={{ fontSize: 11, fill: '#9ca3af' }} />
              <Tooltip formatter={v => [`${v}%`, 'Default rate']} />
              <Line type="monotone" dataKey="rate" stroke="#185FA5" strokeWidth={2} dot={{ r: 3, fill: '#185FA5' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white border border-gray-100 rounded-xl p-5">
        <p className="text-sm font-medium text-gray-900 mb-3">Feature importance (top 6)</p>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={featureData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" horizontal={false} />
            <XAxis type="number" domain={[0, 0.35]} tickFormatter={v => v.toFixed(2)} tick={{ fontSize: 11, fill: '#9ca3af' }} />
            <YAxis type="category" dataKey="name" width={120} tick={{ fontSize: 11, fill: '#6b7280' }} />
            <Tooltip formatter={v => [v.toFixed(2), 'Importance']} />
            <Bar dataKey="importance" fill="#185FA5" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
